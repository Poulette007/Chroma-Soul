using System;
using System.Collections;
using UnityEngine;
using CrashKonijn.Goap.Behaviours;

namespace Enemy.GOAP.WorldKeys
{
    public class IsWandering : WorldKeyBase {}
}
