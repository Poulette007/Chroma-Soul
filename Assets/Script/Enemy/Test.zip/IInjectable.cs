namespace Enemy.GOAP
{
    public interface IInjectable
    {
        public void Inject(DependencyInjector injector);
    }
}