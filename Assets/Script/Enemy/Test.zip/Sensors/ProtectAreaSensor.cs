using UnityEngine;
using CrashKonijn.Goap.Interfaces;
using CrashKonijn.Goap.Sensors;
using Enemy.GOAP.Config;
using UnityEngine.UIElements;
using CrashKonijn.Goap.Classes;
using Enemy.Sensors;
using Enemy.GOAP.WorldKeys;
//using System.Numerics;

namespace Enemy.GOAP.Sensors
{
    public class ProtectAreaSensor : LocalTargetSensorBase, IInjectable
    {
        ProtectAreaConfigSO protectAreaConfigSO;
        WanderConfigSO wanderConfigSO;
        private Collider2D[] collider = new Collider2D[1];
        public override void Created() {}
        public override void Update() {}

        public void Inject(DependencyInjector injector)
        {
            protectAreaConfigSO = injector.protectAreaConfigSO;
            wanderConfigSO = injector.wanderConfigSO;   
        }

        public override ITarget Sense(IMonoAgent agent, IComponentReference references)
        {

            if (protectAreaConfigSO.isPlayerInArea && protectAreaConfigSO.isProtectingArea)
            {
                Debug.Log(collider[0].transform.name + "ProtectAreaSensor -- Attack Action");
                //Debug.Log("enter in Player target  Sensor");

                return new TransformTarget(collider[0].transform);
            }
            else if (protectAreaConfigSO.isProtectingArea)
            {
                Debug.Log("ProtectAreaSensor -- Wander Action");
                Vector2 position = GetRandomDirection(agent); 
                //Debug.Log("enter in protect Area Sensor");
                return new PositionTarget(position);
            }
            Debug.Log("ProtectAreaSensor -- null");
            return null;
        }
        private Vector2 GetRandomDirection(IMonoAgent agent)
        {
            Vector2 randomPosition; 
            do {
                Vector2 direction = new Vector2(Random.Range(-1f, 1f), Random.Range(-1f, 1f)).normalized;
                randomPosition = (Vector2)agent.transform.position + direction * wanderConfigSO.WanderRadius; // Assurez-vous d'avoir une logique pour définir la distance de déplacement
            } while (Vector2.Distance(randomPosition, protectAreaConfigSO.CenterPosition) > protectAreaConfigSO.maxRange);
            Debug.Log("Protect Area Sensor -- randomPosition: " + randomPosition + "\nDistance: " + Vector2.Distance(randomPosition, protectAreaConfigSO.CenterPosition));
            return randomPosition;
        }

        
    }
}