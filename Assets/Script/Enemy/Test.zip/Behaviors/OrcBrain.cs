using System;
using CrashKonijn.Goap.Behaviours;
using Enemy.GOAP.Config;
using Enemy.GOAP.Goals;
using Enemy.Sensors;
using Unity.VisualScripting.ReorderableList.Element_Adder_Menu;
using UnityEngine;

namespace Enemy.GOAP.Behaviors
{
    [RequireComponent(typeof(AgentBehaviour))]
    public class OrcBrain : MonoBehaviour
    {
        [SerializeField] private PlayerSensor playerSensor;
        [SerializeField] private AreaSensor areaSensor;
        [SerializeField] private AttackConfigSO attackConfig;
        [SerializeField] public StatsConfig statsConfig;
        [SerializeField] private ProtectAreaConfigSO protectAreaConfigSO;
        private AgentBehaviour agentBehaviour;
        private AgentMoveBehavior agentMoveBehavior;
        

        private bool isBossArround = false; 

        private void Awake()
        {
            agentBehaviour = GetComponent<AgentBehaviour>();
            agentMoveBehavior = GetComponent<AgentMoveBehavior>();
        }
        private void Start()
        {
            if (!protectAreaConfigSO.isProtectingArea)
            {
                agentBehaviour.SetGoal<WanderGoal>(true);
                UpdateSensorColliderSize();
            }
            else
            {
                Debug.Log("Orc Brain -- ProtectAreaGoal");
                agentBehaviour.SetGoal<ProtectAreaGoal>(true);
                UpdateSensorColliderSize();
            }
            
        }
        private void OnEnable()
        {
            if  (!isBossArround && !protectAreaConfigSO.isProtectingArea)
            {
                playerSensor.OnPlayerEnter += PlayerSensorOnPlayerEnter;
                playerSensor.OnPlayerExit += PlayerSensorOnPlayerExit;
            }
            else if (protectAreaConfigSO.isProtectingArea)
            {
                areaSensor.OnPlayerEnter += PlayerSensorOnPlayerEnter;
                areaSensor.OnPlayerExit += PlayerSensorOnPlayerExit;
            }               
        }
        private void OnDisable()
        {
            if (!isBossArround && !protectAreaConfigSO.isProtectingArea)
            {
                playerSensor.OnPlayerEnter -= PlayerSensorOnPlayerEnter;
                playerSensor.OnPlayerExit -= PlayerSensorOnPlayerExit;
            }
            else if (protectAreaConfigSO.isProtectingArea)
            {
                areaSensor.OnPlayerEnter -= PlayerSensorOnPlayerEnter;
                areaSensor.OnPlayerExit -= PlayerSensorOnPlayerExit;
            } 
        }
        private void PlayerSensorOnPlayerExit(Vector3 lastKnownPosition)
        {
            if (!protectAreaConfigSO.isProtectingArea)
            {
                Debug.Log("Orc Brain -- Wander Goal");
                agentBehaviour.SetGoal<WanderGoal>(true);
            }
            else 
            {
                Debug.Log("Orc Brain -- Protect Area Goal : Player in = false");
                protectAreaConfigSO.isPlayerInArea = false;
                agentBehaviour.SetGoal<ProtectAreaGoal>(true);
            }
            
            //agentBehaviour.SetGoal<WanderGoal>(true);
        }

        private void PlayerSensorOnPlayerEnter(Transform player)
        {
            // Debug.Log("Orc Brain -- Kill player goal");
            // agentBehaviour.SetGoal<KillPlayerGoal>(true);
            if (!protectAreaConfigSO.isProtectingArea)
            {
                Debug.Log("Orc Brain -- Kill Player Goal");
                agentBehaviour.SetGoal<KillPlayerGoal>(true);
            }
            else
            {
                Debug.Log("Orc Brain -- Protect Area Goal: Player in =  true");
                protectAreaConfigSO.isPlayerInArea = true;
                agentBehaviour.SetGoal<ProtectAreaGoal>(true);
            }

            // else if (Vector2.Distance(player.position, protectAreaConfigSO.CenterPosition) < protectAreaConfigSO.maxRange)
            // {
            //     Debug.Log("Orc Brain -- Kill Player Goal");
            //     agentBehaviour.SetGoal<KillPlayerGoal>(true);
            // }
            // else if (Vector2.Distance(player.position, protectAreaConfigSO.CenterPosition) > protectAreaConfigSO.maxRange)
            // {
            //     Debug.Log("Orc Brain -- Kill Player Goal");
            //     agentBehaviour.SetGoal<ProtectAreaGoal>(true);
            // }
            // else
            // {
            //     Debug.LogError("Orc Brain -- PlayerSensorOnPlayerEnter() Error");
            // }
        }
        public void OnBossDetected()
        {
            agentBehaviour.SetGoal<KillPlayerGoal>(false);
            agentBehaviour.SetGoal<WanderGoal>(false);
            agentBehaviour.SetGoal<ProtectAreaGoal>(false); // not sure

            isBossArround = true;
            Debug.Log("boss arround : " + isBossArround);
            
        }

        private void UpdateSensorColliderSize()
        {
            var capsuleCollider = playerSensor.Collider as CapsuleCollider2D;
            if (capsuleCollider != null)
            {
                if (capsuleCollider.direction == CapsuleDirection2D.Horizontal)
                {
                    capsuleCollider.size = new Vector2(attackConfig.sensorRadius, capsuleCollider.size.y);
                }
                else
                {
                    capsuleCollider.size = new Vector2(capsuleCollider.size.x, attackConfig.sensorRadius);
                }
            }
            else
            {
                Debug.LogError("The collider is not a CapsuleCollider2D");
            }
        }
        public void SetTarget(Vector2 targetPosition)
        {
            agentMoveBehavior.MoveTo(targetPosition);
        }
    } 
}