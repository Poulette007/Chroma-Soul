using CrashKonijn.Goap.Behaviours;

namespace Enemy.GOAP.Targets {
    public class PlayerTarget : TargetKeyBase {}
}