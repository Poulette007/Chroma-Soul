using CrashKonijn.Goap.Behaviours;

namespace Enemy.GOAP.Targets
{
    public class ProtectTarget : TargetKeyBase {}
}