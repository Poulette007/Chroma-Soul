using UnityEngine;
using Enemy.GOAP.Config;
using CrashKonijn.Goap.Behaviours;
using CrashKonijn.Goap.Interfaces;
using CrashKonijn.Goap.Enums;
using CrashKonijn.Goap.Classes;

namespace Enemy.GOAP.Actions
{
    public class ProtectAreaAction : ActionBase<AttackData>, IInjectable
    {
        private ProtectAreaConfigSO protectAreaConfigSO;
        private WanderConfigSO wanderConfigSO;

        public override void Created() {}

        public override void End(IMonoAgent agent, AttackData data)
        {
            // animator
        }

        public void Inject(DependencyInjector injector)
        {
            protectAreaConfigSO = injector.protectAreaConfigSO;
            wanderConfigSO = injector.wanderConfigSO;
        }

        public override ActionRunState Perform(IMonoAgent agent, AttackData data, ActionContext context)
        {
            data.Timer -= context.DeltaTime;
            if (data.Timer > 0) {
                return ActionRunState.Continue;
            }
            return ActionRunState.Stop;
        }

        public override void Start(IMonoAgent agent, AttackData data)
        {
            data.Timer = Random.Range(wanderConfigSO.WaitRangeBetweenWanders.x, wanderConfigSO.WaitRangeBetweenWanders.y);
        }
    }
}