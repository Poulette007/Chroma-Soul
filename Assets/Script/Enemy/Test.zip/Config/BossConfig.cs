using UnityEngine;
using UnityEngine.Rendering;

namespace Enemy.GOAP.Config
{
    [CreateAssetMenu(menuName = "AI/Boss Config", fileName = "Boss Config", order = 4)]

    public class BossConfig : ScriptableObject
    {
        public float sensorRadius = 10f;
        public LayerMask detectableLayerMask;
        public int maxDetectedBots = 3;  // Nombre maximum de bots pouvant être détectés simultanément
        public int currentDetectedBots;
    }

}