using CrashKonijn.Goap.Interfaces;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Rendering;

namespace Enemy.GOAP.Config
{
    [CreateAssetMenu(menuName = "AI/ProtectArea Config", fileName = "ProtectArea Config", order = 5)]

    public class ProtectAreaConfigSO : ScriptableObject
    {   
        //public ITarget target; 
        public bool isProtectingArea = false;
        public bool isPlayerInArea = false;
        public float maxRange = 10f;
        public Vector2 CenterPosition = new(30, 0);
    }

}