using CrashKonijn.Goap.Behaviours;

namespace Enemy.GOAP.WorldKeys
{
    public class HasBossOrder : WorldKeyBase {}
}