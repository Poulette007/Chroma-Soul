using CrashKonijn.Goap.Behaviours;
namespace Enemy.GOAP.Goals
{
    public class KillPlayerGoal : GoalBase {}
}