using CrashKonijn.Goap.Behaviours;

namespace Enemy.GOAP.Goals
{
    public class WanderGoal : GoalBase {}
}

