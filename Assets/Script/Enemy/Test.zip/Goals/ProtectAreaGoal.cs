using CrashKonijn.Goap.Behaviours;
namespace Enemy.GOAP.Goals
{
    public class ProtectAreaGoal : GoalBase {}
}